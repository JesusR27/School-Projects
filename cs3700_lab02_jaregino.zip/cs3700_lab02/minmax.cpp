#include "mpi.h"
#include <cstdio>
#include <cmath>
#include <cstdlib>

#define ARRAY_SIZE 1000000
#define small -1000000

int main (int argc,  char *argv[]) {

   int myid, numprocs;
   int namelen;
   int* numbers = new int[ARRAY_SIZE];
   char processor_name[MPI_MAX_PROCESSOR_NAME];
   double random;

   MPI_Init(&argc, &argv);
   MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
   MPI_Comm_rank(MPI_COMM_WORLD, &myid);
   MPI_Get_processor_name(processor_name, &namelen);
 
   printf("Process %d on %s\n", myid, processor_name);
 
   for (int i=0; i<ARRAY_SIZE; i++){
      random = MPI_Wtime();  //using time as our random numbers
      numbers[i] = int (random);
   }

   int s = (int)floor(ARRAY_SIZE/numprocs);
   int s0 = s + ARRAY_SIZE%numprocs;

   int startIndex = s0 + (myid-1)*s;
   int endIndex = startIndex + s;

   double startwtime;
   if (myid == 0) {
      startwtime = MPI_Wtime();
   }

   int i;
   int min = ARRAY_SIZE; //making the min extremely big
   int max = small;  //making the max extremely small
   
   if (myid == 0) {
      // master worker - comput the master's numbers
      for (i=0; i<s0; i++) {
         if (numbers[i] < min){
	    min = numbers[i]; //adding new mins to the array
	 }
         if (numbers[i] > max) {
            max = numbers[i]; //adding new maxes to the array
         }
      }
      printf("Process %d - startIndex 0 endIndex %d;\n min %ld max %ld\n",
             myid, s0-1, min, max);
   } else {
      //slave's work
      for (i= startIndex; i<endIndex; i++) {
         if (numbers[i] < min) {
            min = numbers[i];
         }
         if (numbers[i] > max) {
            max = numbers[i];
         }
      }
      printf ("Process %d - startIndex %d endIndex %d;\n min %ld max %ld\n",
              myid, startIndex, endIndex-1, min, max);
   }
   
   int *final_min = NULL; //has the final min
   int *final_max = NULL; //has the final max
   MPI_Reduce(&min, &final_min, 1, MPI_INT, MPI_MIN, 0, MPI_COMM_WORLD);
   MPI_Reduce(&max, &final_max, 1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);

   if (myid == 0) {
      double runTime = MPI_Wtime() - startwtime;
      printf("Execution time (sec) = %f min = %ld max = %ld \n",
             runTime, final_min, final_max);
   }

   delete[] numbers;

   MPI_Finalize();
}

