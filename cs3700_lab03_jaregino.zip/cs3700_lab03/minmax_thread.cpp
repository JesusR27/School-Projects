#include <chrono>
#include <iostream>
#include <mutex>
#include <random>
#include <utility>
#include <vector>
#include <thread>

using namespace std;

constexpr long long value= 1000000;   
mutex myMutex;

//function for finding min and max
void findM(const vector<int>& val, int thread,
   int& min, int& max, int beg, int end){
    int localMax = 0;   //initialize local variables
    int localMin = 1000000;
    for (auto it= beg; it < end; ++it){    //finding max and min
        if (val[it] > localMax){
            localMax = val[it];
        }
        if (val[it] < localMin){
            localMin = val[it];
        }
    }
    lock_guard<mutex> myLock(myMutex);
    min = localMin;
    max = localMax;

    cout << "Thread[" << thread << "] - slice [max: "  //printing results from each thread
         << max << ", min: " << min << "]" << endl;
}

int main(){

  cout << endl;

  vector<int> randValues;
  randValues.reserve(value); //creating list 
  chrono::duration rand = chrono::system_clock::now().time_since_epoch();  //getting time to use for seed
  unsigned int seed = chrono::duration_cast<chrono::milliseconds>(rand).count();

  mt19937 engine (seed);
  uniform_int_distribution<> uniformDist(1,1000000);   //generating numbers from one to one million
  
  for ( int i=0 ; i < value ; ++i)
     randValues.push_back(uniformDist(engine));    //adding random values to list
 
  int min= 1000000;  //initializing min and max
  int max= 0;
  auto start = chrono::system_clock::now();

  int threads = 8;   //using 8 threads
  thread t[threads];
  long long slice = value / threads;
  int startIdx=0;
  for (int i = 0; i < threads; ++i) {
    t[i] = thread(findM, ref(randValues), i, ref(min), ref(max), startIdx, startIdx+slice-1); //calling the function
    startIdx += slice;
  }

  for (int i = 0; i < threads; ++i)
     t[i].join();

  chrono::duration<double> dur= chrono::system_clock::now() - start;
  cout << "Time for work: " << dur.count() << " seconds" << endl;

  cout << endl;

}