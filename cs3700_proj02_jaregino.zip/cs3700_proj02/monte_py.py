import random
import threading
import time
import math
import sys

lock = threading.Lock()
cir_points = 0 # value for points in circle
random.seed(time.time()) # seed initialized

# function to generate points and finding them in circle (Monte Carlo)
def findPoint(count, id): 
   local = 0
   for i in range(count):
      x = random.uniform(0,1)
      y = random.uniform(0,1)

      origin = x**2 + y**2
      origin = math.sqrt(origin)

      if origin <= 1:
         local += 1 # value for number of points in circle within each thread
   
   with lock:
      global cir_points
      cir_points = cir_points + local # add up values from threads

# function to calculate number of jobs for each thread
def assignJob(numThreads, numPoints):
   # if jobs can be evenly divided, then just divide it
   if (numPoints % numThreads) == 0 or numThreads != (threads - 1):
      return int(numPoints / numThreads)
   
   # if not, then calculate leftover jobs and assign them to final thread
   else:
      leftover = numPoints % int(numPoints/threads)
      return int(numPoints/numThreads) + leftover


if __name__ == "__main__":
   threads = int(sys.argv[1]) # Number of threads to create
   size = int(sys.argv[2])  # Number of random points to create
   print("Number of threads: %d" % threads)
   print("Number of points: %d" % size)

   # needs to be a valid input for number of threads and points
   if (1 <= threads <= 10) and (10 <= size <= 1000000):
      # Create a list of jobs and then iterate through
      # the number of threads appending each thread to
      # the job list
      jobs = []
      for i in range(0, threads):
         out_list = list()
         thread = threading.Thread(target=findPoint(assignJob(threads, size), i))
         jobs.append(thread)

      start_time = time.time()
      # Start the threads 
      for j in jobs:
         j.start()

      # Ensure all of the threads have finished
      for j in jobs:
         j.join()

      # calculating delta and pi
      ratio = cir_points/size
      pi = 4 * ratio
      pi = round(pi, 4)

      delta = math.pi
      delta = delta - pi
      delta = round(delta, 4)

      # printing results
      print ("Estimated Pi: %.4f" % pi)
      print ("Delta: %.4f" % delta)
      print ("Time for calculations: %s seconds" % round((time.time() - start_time), 15))

   else:
      print("Input for number of threads and/or points is invalid.")
