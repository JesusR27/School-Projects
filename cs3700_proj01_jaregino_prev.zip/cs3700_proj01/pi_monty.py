#!/usr/bin/python3.4

from mpi4py import MPI
import math
import random
import sys                      # for inputting something
   
#start up MPI
world = MPI.COMM_WORLD
numprocs = world.size           # number of processors
myid = world.rank
procname = MPI.Get_processor_name()

trials = int(sys.argv[1])       # number of points created (uses the value inputted)
points = int(trials/numprocs)   # number of points each node has to work on
random.seed(myid + MPI.Wtime()) # initialize random number generator
cir_points = 0                  # keeps track of points in circle

# Monte Carlo method process
for j in range(points):
    
    # start the timer
    if myid == 0:
        startwtime = MPI.Wtime()
    
    # master worker
    if myid == 0:
        x = random.uniform(0, 1)
        y = random.uniform(0, 1)

        # calculate the distance from origin
        origin = x**2 + y**2
        origin = math.sqrt(origin)

        # find points that are inside circle
        if origin <= 1:
            cir_points += 1

    # slave worker
    else:
        x = random.uniform(0, 1)
        y = random.uniform(0, 1)

        origin = x**2 + y**2
        origin = math.sqrt(origin)

        if origin <= 1:
            cir_points += 1
    
    # find sum
    sum = world.reduce(cir_points, op=MPI.SUM, root=0)

    if myid == 0:
        # initializing delta, contains pi at start
        delta = math.pi 

        # calculating the pi value
        ratio = sum / trials
        pi = 4 * ratio
        pi = round(pi, 4)

        # calculating delta
        delta = delta - pi
        delta = round(delta, 4)

        # calculating time
        endwtime = MPI.Wtime()
        runTime = endwtime - startwtime
        runTime = round(runTime, 6)

        # printing results
        if j == points - 1:
            print('Nodes: %d \nPoints: %d \nEstimated Pi: %.4f \nDelta: %.4f \nTime: %.6f'
            %(numprocs, trials, pi, delta, runTime))


